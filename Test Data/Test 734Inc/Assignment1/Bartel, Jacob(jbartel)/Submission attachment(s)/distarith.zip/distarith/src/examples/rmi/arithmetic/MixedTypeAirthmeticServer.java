package examples.rmi.arithmetic;

public interface MixedTypeAirthmeticServer {
	public static final String SERVER_NAME = "Remote Mixed Type Arithmetic";
}
